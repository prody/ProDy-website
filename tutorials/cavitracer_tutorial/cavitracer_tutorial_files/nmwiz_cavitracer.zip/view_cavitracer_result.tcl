# CaviTracer multi-frame result viewer for VMD.
# Update these paths, then run: source view_cavitracer_result.tcl
set result_file "result.pdb"
set radii_file "result.radii"

proc read_cavitracer_radii {filename} {
    set handle [open $filename r]
    try {
        if {[gets $handle] ne "NMWIZ_CAVITRACER_RADII 1"} {
            error "Unsupported CaviTracer radius-file format: $filename"
        }
        if {![regexp {^FRAMES ([0-9]+) ATOMS ([0-9]+)$} \
                [gets $handle] -> nframes natoms]} {
            error "Invalid radius-file dimensions: $filename"
        }
        set frames {}
        for {set frame 0} {$frame < $nframes} {incr frame} {
            if {[gets $handle] ne "FRAME $frame"} {
                error "Missing radius data for frame $frame"
            }
            if {[gets $handle line] < 0} {
                error "Missing radius values for frame $frame"
            }
            set values [split [string trim $line]]
            if {[llength $values] != $natoms} {
                error "Frame $frame has [llength $values] radii; expected $natoms"
            }
            lappend frames $values
        }
        return $frames
    } finally {
        close $handle
    }
}

proc update_cavitracer_radii {molid args} {
    if {[lsearch -exact [molinfo list] $molid] < 0} {
        return
    }
    set frame [molinfo $molid get frame]
    set selection [atomselect $molid all frame $frame]
    try {
        $selection set radius [lindex $::cavitracer_radii($molid) $frame]
    } finally {
        $selection delete
    }
}

set frame_radii [read_cavitracer_radii $radii_file]
set molid [mol new $result_file type pdb waitfor all]
if {[molinfo $molid get numframes] != [llength $frame_radii]} {
    mol delete $molid
    error "PDB frame count does not match the radius file"
}
set ::cavitracer_radii($molid) $frame_radii

mol delrep 0 $molid
mol representation VDW 1.0 12.0
mol color ColorID 0
mol selection {occupancy > 0}
mol material Opaque
mol addrep $molid
mol selupdate 0 $molid on

trace add variable ::vmd_frame($molid) write \
    [list update_cavitracer_radii $molid]
animate goto 0
update_cavitracer_radii $molid
