#!/usr/bin/env python3

"""Analyze channels, pores, or surface cavities along a reconstructed ANM mode.

The input NMD is converted to an all-atom ensemble before CaviTracer analysis.
Results are exported as a multi-model PDB with per-frame sphere radii.
"""

import argparse
import gc
import os
import re
import shutil
import tempfile
from pathlib import Path

from prody import (
    ANM,
    ClustENM,
    extendModel,
    parseNMD,
    parsePDB,
    traverseMode,
    writePDB,
)

try:
    from prody import (
        calcChannelsMultipleFrames,
        calcPoresFromChannelsMultipleFrames,
        calcSurfaceCavitiesMultipleFrames,
        getChannelParameters,
        getPoreParameters,
        getSurfaceCavityParameters,
    )
except ImportError:
    from prody.proteins.channels import (
        calcChannelsMultipleFrames,
        calcPoresFromChannelsMultipleFrames,
        calcSurfaceCavitiesMultipleFrames,
        getChannelParameters,
        getPoreParameters,
        getSurfaceCavityParameters,
    )


def optional_float(value):
    """Convert a non-empty command-line value to float; blank means None."""
    if value is None or str(value).strip() == "":
        return None
    return float(value)


def safe_name(value):
    value = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value).strip())
    return value.strip("._") or "nmwiz"


def frame_process_limit(ensemble):
    """Use all cores for short runs and cap longer runs at four workers."""
    return 4 if ensemble.numCoordsets() > 20 else None


def clean_dir(path):
    path = Path(path)
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def natural_key(path):
    return [int(part) if part.isdigit() else part.lower()
            for part in re.split(r"(\d+)", Path(path).name)]


def coordinate_files(folder, frame_count=None):
    """Return per-frame result files, including ``None`` for empty frames."""
    folder = Path(folder)
    files = []
    for suffix in ("*.pqr", "*.pdb"):
        files.extend(folder.rglob(suffix))
    files = [path for path in set(files)
             if not path.name.endswith("_links.pqr")]
    files = sorted(files, key=natural_key)
    if frame_count is None:
        return files

    slots = [None] * frame_count
    for path in files:
        match = re.search(r"(\d+)(?=\.(?:pqr|pdb)$)", path.name,
                          flags=re.IGNORECASE)
        if match is None:
            continue
        frame = int(match.group(1))
        if 0 <= frame < frame_count:
            if slots[frame] is not None:
                raise RuntimeError(
                    f"More than one result file was found for frame {frame}: "
                    f"{slots[frame]} and {path}"
                )
            slots[frame] = path
    return slots


def set_pdb_occupancy(line, occupancy):
    """Return an atom record with a controlled PDB occupancy field."""
    record = line.rstrip("\r\n")
    if len(record) < 60:
        record = record.ljust(60)
    return f"{record[:54]}{occupancy:6.2f}{record[60:]}\n"


def atom_radius(line, source_path):
    """Read a CaviTracer sphere radius from a PQR (or PDB fallback)."""
    if source_path.suffix.lower() == ".pqr":
        fields = line.split()
        if len(fields) < 2:
            raise ValueError(f"Malformed PQR atom record in {source_path}: {line!r}")
        try:
            radius = float(fields[-1])
        except ValueError as exc:
            raise ValueError(
                f"Invalid PQR radius in {source_path}: {fields[-1]!r}"
            ) from exc
    else:
        try:
            radius = float(line[60:66])
        except (ValueError, IndexError):
            radius = 1.0
    if radius < 0:
        raise ValueError(f"Negative sphere radius {radius} in {source_path}")
    return radius


def write_radius_data(path, radius_models, max_atoms):
    """Write frame-specific VDW radii in a compact, Tcl-friendly format."""
    path = Path(path)
    with path.open("w") as output:
        output.write("NMWIZ_CAVITRACER_RADII 1\n")
        output.write(f"FRAMES {len(radius_models)} ATOMS {max_atoms}\n")
        for frame, radii in enumerate(radius_models):
            padded = radii + [0.0] * (max_atoms - len(radii))
            output.write(f"FRAME {frame}\n")
            output.write(" ".join(f"{radius:.6g}" for radius in padded) + "\n")
    return path


def merge_models(model_files, output_pdb, radius_file=None):
    """Merge results into a fast PDB trajectory and write per-frame radii."""
    model_files = list(model_files)
    if not model_files:
        raise FileNotFoundError("No per-frame CaviTracer coordinate files were found.")

    dummy_line = (
        "HETATM    1  C   DUM X   1       0.000   0.000   0.000"
        "  0.00  0.00           C  \n"
    )
    models = []
    radius_models = []
    for model_file in model_files:
        if model_file is None:
            models.append((None, []))
            radius_models.append([])
            continue
        model_file = Path(model_file)
        with model_file.open() as source:
            atom_lines = [
                line if line.endswith("\n") else line + "\n"
                for line in source
                if line.startswith(("ATOM  ", "HETATM"))
            ]
        models.append((model_file, atom_lines))
        radius_models.append([atom_radius(line, model_file) for line in atom_lines])

    counts = [len(atom_lines) for _, atom_lines in models]
    max_atoms = max(1, max(counts))
    output_pdb = Path(output_pdb)
    output_pdb.parent.mkdir(parents=True, exist_ok=True)

    with output_pdb.open("w") as output:
        for model_number, (model_file, atom_lines) in enumerate(models, start=1):
            output.write(f"MODEL     {model_number:4d}\n")
            source_name = model_file.name if model_file is not None else "no results"
            output.write(
                f"REMARK Source {source_name}; original atoms "
                f"{len(atom_lines)}; padded atoms {max_atoms}\n"
            )
            output.writelines(set_pdb_occupancy(line, 1.0)
                              for line in atom_lines)
            padding_source = atom_lines[-1] if atom_lines else dummy_line
            padding_line = set_pdb_occupancy(padding_source, 0.0)
            output.writelines([padding_line] * (max_atoms - len(atom_lines)))
            output.write("ENDMDL\n")
        output.write("END\n")

    if radius_file is None:
        radius_file = output_pdb.with_suffix(".radii")
    radius_file = write_radius_data(radius_file, radius_models, max_atoms)

    print(
        f"Merged {len(models)} frames with {min(counts)}-{max(counts)} "
        f"real atoms per frame; padded each to {max_atoms}."
    )
    return output_pdb, radius_file, counts


def write_parameter_details(path, analysis, objects_by_frame):
    """Write one readable parameter table for every result frame."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    with path.open("w", encoding="utf-8") as output:
        if analysis in ("channel", "pore"):
            label = analysis
            output.write(
                f"{label.title()} ID\tVolume [Å³]\tLength [Å]\t"
                "Bottleneck [Å]\n"
            )
            getter = (getChannelParameters if analysis == "channel"
                      else getPoreParameters)
            for frame, objects in enumerate(objects_by_frame):
                output.write(f"Frame {frame}\n")
                if not objects:
                    output.write(f"No {label}s found\n")
                    continue
                lengths, bottlenecks, volumes = getter(objects)
                for index, (volume, length, bottleneck) in enumerate(
                        zip(volumes, lengths, bottlenecks)):
                    output.write(
                        f"{label} {index}\t{float(volume):.2f}\t"
                        f"{float(length):.2f}\t{float(bottleneck):.2f}\n"
                    )
        else:
            output.write(
                "Surface cavity ID\tVolume [Å³]\tDepth [Å]\t"
                "Tetrahedra count\n"
            )
            for frame, cavities in enumerate(objects_by_frame):
                output.write(f"Frame {frame}\n")
                if not cavities:
                    output.write("No surface cavities found\n")
                    continue
                volumes, depths, tetrahedra_counts = \
                    getSurfaceCavityParameters(cavities)
                for index, (volume, depth, count) in enumerate(
                        zip(volumes, depths, tetrahedra_counts)):
                    output.write(
                        f"surface cavity {index}\t{float(volume):.2f}\t"
                        f"{float(depth):.2f}\t{int(count)}\n"
                    )

    return path


def build_mode_ensemble(nmd_file, mode_number, frame_count, rmsd, run_dir):
    """Fix/protonate the NMD atoms, rebuild an all-atom ANM, and traverse it."""
    _, atom_group = parseNMD(str(nmd_file))
    base = safe_name(nmd_file.stem)
    atom_group.setTitle(base)

    # Normalize PDB atom flags required by ClustENM.
    normalized_path = Path(run_dir) / f"{base}_from_nmd.pdb"
    writePDB(str(normalized_path), atom_group)
    atom_group = parsePDB(str(normalized_path))
    if atom_group is None:
        raise ValueError("Could not convert the NMD atoms to a PDB AtomGroup.")
    atom_group.setTitle(base)

    # Some ProDy builds omit the hetatm flag for ATOM-only files.
    try:
        atom_group.select("not hetatm")
    except Exception:
        import numpy as np
        atom_group.setFlags("hetatm", np.zeros(atom_group.numAtoms(), dtype=bool))

    previous_cwd = Path.cwd()
    try:
        os.chdir(run_dir)
        cenm = ClustENM("temp")
        cenm.setAtoms(atom_group)
        cenm.writePDBFixed()

        # Access the fixed structure directly; output filenames vary by version.
        fixed = cenm.getAtoms()
        if fixed is None:
            raise RuntimeError(
                "ClustENM fixed the structure but did not retain an AtomGroup."
            )
        fixed = fixed.copy()
    finally:
        os.chdir(previous_cwd)

    if fixed is None or fixed.ca is None:
        raise ValueError("The ClustENM-fixed structure contains no C-alpha atoms.")

    ca = fixed.ca
    anm = ANM(f"{base}_rebuilt")
    anm.buildHessian(ca)
    anm.calcModes(n_modes=mode_number)
    anm_ext, prot_all = extendModel(anm, ca, fixed, norm=True)

    # Match NMWiz's frame count while preserving symmetric mode traversal.
    n_steps = (frame_count + 1) // 2
    ensemble = traverseMode(
        anm_ext[mode_number - 1], prot_all, n_steps=n_steps, rmsd=rmsd
    )

    if frame_count % 2:
        center = ensemble.numCoordsets() // 2
        if hasattr(ensemble, "delCoordset"):
            ensemble.delCoordset(center)
        else:
            import numpy as np
            coordsets = np.delete(ensemble.getCoordsets(), center, axis=0)
            ensemble.setCoordsets(coordsets)

    expected_frames = frame_count + 1
    trajectory_path = Path(run_dir) / (
        f"{base}_mode{mode_number}_RMSD{rmsd:g}A_{expected_frames}frames.pdb"
    )
    writePDB(str(trajectory_path), ensemble)
    ensemble = parsePDB(str(trajectory_path))
    if ensemble.numCoordsets() != expected_frames:
        raise RuntimeError(
            f"Expected {expected_frames} frames, but traverseMode produced "
            f"{ensemble.numCoordsets()}."
        )
    print(
        f"NMWiz frame setting {frame_count}: n_steps={n_steps}, "
        f"generated {expected_frames} ensemble frames."
    )
    return ensemble, base, trajectory_path


def add_if_not_none(mapping, key, value):
    if value is not None:
        mapping[key] = value


def run_channel(args, ensemble, result_dir):
    output_dir = result_dir / "channel_frames"
    clean_dir(output_dir)

    start_point = None
    if args.use_start_point:
        start_point = [
            args.start_x,
            args.start_y,
            args.start_z,
        ]

    channel_options = {
        "surf_radius": args.surface_radius,
        "inner_radius": args.inner_radius,
        "sparsity": args.sparsity,
        "start_point": start_point,
    }
    add_if_not_none(channel_options, "min_depth", args.min_depth)
    add_if_not_none(channel_options, "min_volume", args.min_volume)
    if args.max_volume is not None:
        channel_options["max_volume"] = args.max_volume
    add_if_not_none(channel_options, "bottleneck", args.bottleneck)

    print("Channel calculation parameters:")
    for name, value in channel_options.items():
        print(f"  {name} = {value}")

    channels_all, _surfaces_all = calcChannelsMultipleFrames(
        ensemble,
        trajectory=None,
        output_path=str(output_dir / "channels.pdb"),
        max_proc=frame_process_limit(ensemble),
        stop_frame=ensemble.numCoordsets(),
        separate=False,
        **channel_options,
    )

    return coordinate_files(output_dir, ensemble.numCoordsets()), channels_all


def run_surface(args, ensemble, result_dir):
    output_dir = result_dir / "surface_cavity_frames"
    clean_dir(output_dir)
    options = {
        "surf_radius": args.surface_radius,
        "inner_radius": args.inner_radius,
        "min_depth": args.surface_min_depth,
        "max_depth": args.surface_max_depth,
        "min_volume": args.min_volume,
    }
    add_if_not_none(options, "max_volume", args.max_volume)
    cavities_all, _surfaces_all = calcSurfaceCavitiesMultipleFrames(
        ensemble, trajectory=None,
        output_path=str(output_dir / "surface_cavities.pdb"),
        max_proc=frame_process_limit(ensemble),
        # Surface-cavity stop_frame is an inclusive, zero-based index.
        stop_frame=ensemble.numCoordsets() - 1, separate=False,
        **options,
    )
    return coordinate_files(output_dir, ensemble.numCoordsets()), cavities_all


def run_pore(args, ensemble, result_dir):
    channel_dir = result_dir / "pore_channel_frames"
    pore_dir = result_dir / "pore_frames"
    clean_dir(channel_dir)
    clean_dir(pore_dir)

    start_point = None
    if args.use_start_point:
        start_point = [args.start_x, args.start_y, args.start_z]

    channels_all, _surfaces_all, details_all = calcChannelsMultipleFrames(
        ensemble, trajectory=None,
        output_path=str(channel_dir / "channels.pdb"),
        max_proc=frame_process_limit(ensemble), surf_radius=args.surface_radius,
        inner_radius=args.inner_radius, start_point=start_point,
        return_details=True, stop_frame=ensemble.numCoordsets(),
        separate=False,
    )
    # Release unused surfaces before the pore-processing stage.
    del _surfaces_all
    gc.collect()

    filters = {}
    add_if_not_none(filters, "min_end_to_end", args.pore_min_end_to_end)
    add_if_not_none(filters, "max_end_to_end", args.pore_max_end_to_end)
    add_if_not_none(filters, "min_bottleneck", args.pore_min_bottleneck)
    add_if_not_none(filters, "max_bottleneck", args.pore_max_bottleneck)
    add_if_not_none(filters, "min_length", args.pore_min_length)
    add_if_not_none(filters, "max_length", args.pore_max_length)
    add_if_not_none(filters, "min_volume", args.pore_min_volume)
    add_if_not_none(filters, "max_volume", args.pore_max_volume)

    pores_all = calcPoresFromChannelsMultipleFrames(
        channels_all, details_all,
        output_path=str(pore_dir / "pores.pdb"),
        max_proc=frame_process_limit(ensemble), separate=False, **filters,
    )
    return coordinate_files(pore_dir, ensemble.numCoordsets()), pores_all


def positive(value, label, allow_zero=False):
    if value is None:
        return
    if value < 0 or (value == 0 and not allow_zero):
        qualifier = "zero or positive" if allow_zero else "positive"
        raise ValueError(f"{label} must be {qualifier}.")


def validate(args):
    if args.mode < 1:
        raise ValueError("Mode number must be at least 1.")
    if args.rmsd <= 0:
        raise ValueError("RMSD must be positive.")
    if args.frame < 2:
        raise ValueError("Animation frame setting must be an integer of at least 2.")

    positive(args.inner_radius, "Inner radius")
    if args.analysis == "channel":
        positive(args.surface_radius, "Surface radius")
        positive(args.sparsity, "Sparsity")
        positive(args.min_depth, "Minimum depth", allow_zero=True)
        positive(args.min_volume, "Minimum volume", allow_zero=True)
        positive(args.max_volume, "Maximum volume", allow_zero=True)
        positive(args.bottleneck, "Bottleneck", allow_zero=True)
        if (args.min_volume is not None and args.max_volume is not None and
                args.max_volume < args.min_volume):
            raise ValueError("Maximum volume must be at least the minimum volume.")
        if args.use_start_point and None in (args.start_x, args.start_y, args.start_z):
            raise ValueError("Start-point X, Y, and Z are required when enabled.")
    elif args.analysis == "surface":
        positive(args.surface_radius, "Surface radius")
        positive(args.surface_min_depth, "Minimum surface depth", allow_zero=True)
        positive(args.surface_max_depth, "Maximum surface depth", allow_zero=True)
        positive(args.min_volume, "Minimum volume", allow_zero=True)
        positive(args.max_volume, "Maximum volume", allow_zero=True)
        if args.surface_max_depth < args.surface_min_depth:
            raise ValueError("Maximum surface depth must be at least the minimum depth.")
        if (args.min_volume is not None and args.max_volume is not None and
                args.max_volume < args.min_volume):
            raise ValueError("Maximum volume must be at least the minimum volume.")
    else:
        positive(args.surface_radius, "Surface radius")
        if args.use_start_point and None in (args.start_x, args.start_y, args.start_z):
            raise ValueError("Start-point X, Y, and Z are required when enabled.")
        pairs = (
            (args.pore_min_end_to_end, args.pore_max_end_to_end, "end-to-end distance"),
            (args.pore_min_bottleneck, args.pore_max_bottleneck, "bottleneck"),
            (args.pore_min_length, args.pore_max_length, "length"),
            (args.pore_min_volume, args.pore_max_volume, "volume"),
        )
        for minimum, maximum, label in pairs:
            positive(minimum, f"Minimum pore {label}", allow_zero=True)
            positive(maximum, f"Maximum pore {label}", allow_zero=True)
            if minimum is not None and maximum is not None and maximum < minimum:
                raise ValueError(f"Maximum pore {label} must be at least its minimum.")


def make_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--analysis", required=True,
                        choices=("channel", "surface", "pore"))
    parser.add_argument("--nmd", required=True)
    parser.add_argument("--mode", required=True, type=int,
                        help="One-based mode index in the rebuilt ANM.")
    parser.add_argument("--rmsd", required=True, type=float)
    parser.add_argument("--frame", required=True, type=int,
                        help="NMWiz frame setting; generated ensemble has frame+1 frames.")
    parser.add_argument("--output-dir", default=".")
    parser.add_argument("--save", action="store_true")
    parser.add_argument("--save-details", action="store_true")

    parser.add_argument("--surface-radius", type=float, default=4.5)
    parser.add_argument("--inner-radius", type=float, default=1.2)
    parser.add_argument("--sparsity", type=float, default=1.0)
    parser.add_argument("--min-depth", type=optional_float)
    parser.add_argument("--min-volume", type=optional_float)
    parser.add_argument("--max-volume", type=optional_float)
    parser.add_argument("--bottleneck", type=optional_float)
    parser.add_argument("--surface-min-depth", type=float, default=1.5)
    parser.add_argument("--surface-max-depth", type=float, default=2.5)

    parser.add_argument("--use-start-point", action="store_true")
    parser.add_argument("--start-x", type=optional_float)
    parser.add_argument("--start-y", type=optional_float)
    parser.add_argument("--start-z", type=optional_float)
    for option in (
        "pore-min-end-to-end", "pore-max-end-to-end",
        "pore-min-bottleneck", "pore-max-bottleneck",
        "pore-min-length", "pore-max-length",
        "pore-min-volume", "pore-max-volume",
    ):
        parser.add_argument(f"--{option}", type=optional_float)
    return parser


def main():
    args = make_parser().parse_args()
    validate(args)

    nmd_file = Path(args.nmd).expanduser().resolve()
    if not nmd_file.is_file():
        raise FileNotFoundError(f"NMD file does not exist: {nmd_file}")
    output_dir = Path(args.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    run_dir = Path(tempfile.mkdtemp(prefix="nmwiz_cavitracer_", dir=output_dir))
    try:
        ensemble, base, _trajectory = build_mode_ensemble(
            nmd_file, args.mode, args.frame, args.rmsd, run_dir
        )
        if args.analysis == "channel":
            files, objects_by_frame = run_channel(args, ensemble, run_dir)
        elif args.analysis == "surface":
            files, objects_by_frame = run_surface(args, ensemble, run_dir)
        else:
            files, objects_by_frame = run_pore(args, ensemble, run_dir)

        files = list(reversed(files))
        objects_by_frame = list(reversed(objects_by_frame))
        print("Reversed CaviTracer frame order to match the NMWiz animation.")

        actual_frames = ensemble.numCoordsets()
        result_stem = (
            f"{base}_mode{args.mode}_RMSD{args.rmsd:g}A_"
            f"{actual_frames}frames_{args.analysis}"
        )

        if args.save:
            result = output_dir / f"{result_stem}.pdb"
        else:
            handle, name = tempfile.mkstemp(
                prefix=f"nmwiz_{args.analysis}_", suffix=".pdb", dir=output_dir
            )
            os.close(handle)
            result = Path(name)

        if args.save_details:
            details_file = write_parameter_details(
                output_dir / f"{result_stem}_detail.txt",
                args.analysis,
                objects_by_frame,
            )
            print(f"RESULT_DETAILS={details_file.resolve()}")

        # Report an empty search before creating a padded visualization trajectory.
        if not any(len(objects) > 0 for objects in objects_by_frame
                   if objects is not None):
            if not args.save:
                result.unlink(missing_ok=True)
            print("RESULT_EMPTY=1")
            label = {"channel": "channels", "pore": "pores",
                     "surface": "surface cavities"}[args.analysis]
            print(f"No {label} found.")
            return

        radius_file = result.with_suffix(".radii")
        result, radius_file, frame_counts = merge_models(
            files, result, radius_file=radius_file
        )
        print("FRAME_COUNTS=" + ",".join(str(count) for count in frame_counts))
        print(f"RESULT_RADII={radius_file.resolve()}")
        print(f"RESULT_PDB={result.resolve()}")
        print(f"Find {args.analysis} finished: {len(files)} result frames.")
    finally:
        shutil.rmtree(run_dir, ignore_errors=True)


if __name__ == "__main__":
    main()
